
package Clases;

import java.io.Serializable;

public class Actividad implements Serializable{
    
    private int id;
    private String tipo;
    private String horario;
    private int aforo;
    private int sala;

    public Actividad(int id, String tipo, String horario, int aforo, int sala) {
        this.id = id;
        this.tipo = tipo;
        this.horario = horario;
        this.aforo = aforo;
        this.sala = sala;
    }

    public Actividad() {
    }
    
    
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public int getAforo() {
        return aforo;
    }

    public void setAforo(int aforo) {
        this.aforo = aforo;
    }

    public int getSala() {
        return sala;
    }

    public void setSala(int sala) {
        this.sala = sala;
    }
    
    
}
