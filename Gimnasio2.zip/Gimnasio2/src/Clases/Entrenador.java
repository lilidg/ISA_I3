
package Clases;

import java.util.ArrayList;

public class Entrenador extends Usuario {
    
    private String horas_libres;
    private String horas_reservadas;
    private ArrayList<Socio> socios;
    private ArrayList<Actividad> actividades;

    public Entrenador(String horas_libres, String horas_reservadas, int id, String dni, String nombre, String email, String clave) {
        super(id, dni, nombre, email, clave);
        this.horas_libres = horas_libres;
        this.horas_reservadas = horas_reservadas;
    }

   

    public String getHoras_libres() {
        return horas_libres;
    }

    public void setHoras_libres(String horas_libres) {
        this.horas_libres = horas_libres;
    }

    public String getHoras_reservadas() {
        return horas_reservadas;
    }

    public void setHoras_reservadas(String horas_reservadas) {
        this.horas_reservadas = horas_reservadas;
    }

    public ArrayList<Socio> getSocios() {
        return socios;
    }

    public void setSocios(ArrayList<Socio> socios) {
        this.socios = socios;
    }

    public ArrayList<Actividad> getActividades() {
        return actividades;
    }

    public void setActividades(ArrayList<Actividad> actividades) {
        this.actividades = actividades;
    }
    
    
    
}
