
package Clases;

public class Factura {
    
    private int num;
    private float importe;

    public Factura(int num, float importe) {
        this.num = num;
        this.importe = importe;
    }
    
    

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public float getImporte() {
        return importe;
    }

    public void setImporte(float importe) {
        this.importe = importe;
    }
    
    
}
