
package Clases;

import Interfaz.JFrameInicio;
import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JFrame;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;




public class GymMain implements Serializable {
    
    public boolean inicializado;
    
    private ArrayList<String> contenidoFichero;
    
    Connection con=null;
    private final String url="jdbc:postgresql://127.0.0.1:5432/GIMNASIO";
    private final String user="postgres";
    private final String password="0104";

    
    
    public GymMain() {
        this.contenidoFichero = new ArrayList<String>();
    }
    
    
//-----------------Base de datos--------------------------------
    public Connection connect() throws SQLException{
        try{
            con=DriverManager.getConnection(url, user, password);
            System.out.println("Conectado");
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return con;
    }

    public void disconnect(){
        try{
            con.close();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public void insertar(Socio s){
        try {
            Connection conexion = connect();   
            java.sql.Statement st = conexion.createStatement();
            String sql = "insert into Socio(id,dni,nombre,email,clave,cuenta,cuota,telefono) values ('"+s.getId()+"','"+s.getDni()+"', '"+s.getNombre()+"','"+s.getEmail()+"','"+s.getClave()+"','"+s.getCuenta()+"','"+s.getCuota()+"','"+s.getTelefono()+"');";
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "El registro se guardó correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, "El registro NO se guardó correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        }
    }
    
    public void cargarDatos() throws SQLException{
        Connection conexion = connect();
        java.sql.Statement pst = null;
        
        String todo = "SELECT * FROM INFORMATION_SCHEMA.TABLES";
        
    }
    
    
    
    
    //---------INICIALIZAR----------
    public static void guardarDatos(ArrayList<Usuario> usuarios,String nombreFichero){
         
        try {
            ObjectOutputStream ficheroSalida = new ObjectOutputStream(new FileOutputStream(nombreFichero));
            ficheroSalida.writeObject(usuarios);
            ficheroSalida.flush();
            ficheroSalida.close();
            
 
        } catch (FileNotFoundException fnfe) {
            System.out.println("Error escritura: El fichero no existe. " + fnfe.toString());
        } catch (IOException ioe) {
            System.out.println("Error escritura: Fallo en la escritura en el fichero. " + ioe.toString());
        }
    }

     private static ArrayList<Usuario> recuperarDatos(String fichero){
        
        ArrayList<Usuario> datosRecuperados = new ArrayList<>();
        try{
            ObjectInputStream ficheroEntrada;
            ficheroEntrada = new ObjectInputStream(new FileInputStream(fichero));
            datosRecuperados= (ArrayList<Usuario>) ficheroEntrada.readObject();
            ficheroEntrada.close();         
            
        }catch (FileNotFoundException fnfe){
            System.out.println("Error lectura: Fichero no existe" + fnfe.toString());
        }catch (IOException ioe){
            System.out.println("Error en la lectura del fichero" + ioe.toString());
        } catch (ClassNotFoundException ex) {
            System.out.println("Error lectura:" +  ex.toString());
        }       
        
        return datosRecuperados;
    }
    
    //---------FICHERO LOG-----------
    public void crearFichero(){
        try{
            FileWriter fichero=new FileWriter("src/Log/informe.txt");
            fichero.close();
        }catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void añadirArray(String fichero){
        contenidoFichero.add(fichero);
        escribirFichero();
    }
    
    public void escribirFichero(){
        try{
                FileWriter escribir=new FileWriter("src/Log/informe.txt");
                String info=""; //en esta variable almacenamos todos los valores del arrayList, que son las líneas del fichero
                for(int i=0; i<contenidoFichero.size(); i++){
                    info=info+contenidoFichero.get(i)+"\n";
                }
                escribir.write(info); //guardamos todo en el fichero
                escribir.close();
            }catch(IOException e){
                System.out.println("Error");
                e.printStackTrace();
            }
    }
    
    

    
    
    
    public static void main(String[] args) throws SQLException {
        
        GymMain app = new GymMain();
        app.connect();
        app.disconnect();
        
        GymMain fichero = new GymMain();
        fichero.crearFichero();
        
        String ficheroUsuarios="ficheroUsuarios";
        
        ArrayList<Usuario> usuarios = recuperarDatos(ficheroUsuarios);
        
        String abs=(new File(".").getAbsolutePath()); 
        String finalPath=abs.replace(".","images\\");
        
        
        /*try{
            if(!usuarios.get(0).getInicializado()){//SI LOS DATOS NO HAN SIDO INICIALIZADOS
                usuarios=inicializar(finalPath);//INICIALIZA CON EL PATH DE LAS IMAGENES
            }
            
        }catch(Exception e){
            usuarios=inicializar(finalPath);//INICIALIZA CON EL PATH DE LAS IMAGENES
        }*/
        
        Logica l = new Logica(usuarios, finalPath);
        
        JFrameInicio ventanaInicio=new JFrameInicio(l);
        ventanaInicio.setLocationRelativeTo(null);
        ventanaInicio.setVisible(true); 
        
        
    }   
    
    public static ArrayList<Usuario> inicializar(String finalPath){
    
        //------------------------SOCIOS------------------------
        Socio socio1 = new Socio("647373929", 25, "ES7537397437983", 123, "02673891X", "Juan", "juan@gmail.com", "juanito123");
        
        //------------------------ENTRENADORES-------------------------
        Entrenador entrenador1 = new Entrenador("2", "6", 78, "86234190P", "Javier", "javier@gmail.com", "javier78");
        
        //------------------------MONITORES-------------------------
        Monitor monitor1 = new Monitor("Mañana", 15, "07825609L", "Fernando", "fernando@gmail.com", "fernando15");
        
        //------------------------LIMPIADORES-------------------------
        Limpiador limpiador1 = new Limpiador("Tarde", "Vestuarios", 83, "78341121D", "Sergio", "sergio@gmail.com", "sergio83");
        
        //------------------------RECEPCIONISTA-------------------------
        Recepcionista recepcionista1 = new Recepcionista(8, "45009810F", "Felipe", "felipe@gmail.com", "felipe8");
        
        //------------------------PRESIDENTE-------------------------
        Presidente presidente1 = new Presidente(1, "54982319N", "Eduardo", "eduardo@gym.com", "admin");
        
        //------------------------ACTIVIDADES------------------------
        Actividad actividad1 = new Actividad(15, "Fitness", "12:00-14:00",20, 4);
        
        
        
        socio1.setActividadesReservadas(actividad1);
        
        entrenador1.getSocios().add(socio1);
        entrenador1.getActividades().add(actividad1);
        
        monitor1.getPuntuaciones().add(8);
        monitor1.getPuntuaciones().add(3);
        monitor1.getPuntuaciones().add(1);
        
        
        //------------------------ARRAYLIST USUARIOS------------------------
        ArrayList<Usuario> usuarios = new ArrayList();
        
        usuarios.add(socio1);
        usuarios.add(entrenador1);
        usuarios.add(monitor1);
        usuarios.add(limpiador1);
        usuarios.add(presidente1);
        usuarios.add(recepcionista1);
        

        return usuarios;
    }
    
}
