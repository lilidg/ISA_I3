
package Clases;


public class Limpiador extends Usuario{
    
    private String turno;
    private String zona;

    public Limpiador(String turno, String zona, int id, String dni, String nombre, String email, String clave) {
        super(id, dni, nombre, email, clave);
        this.turno = turno;
        this.zona = zona;
    }
    

    
    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }
    
    
}
