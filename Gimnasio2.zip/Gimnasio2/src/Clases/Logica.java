
package Clases;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Logica {
    
    //ArrayList de todos los tipos de usuarios
    private ArrayList<Usuario> usuarios;
    private ArrayList<Socio> socios;
    private ArrayList<Entrenador> entrenadores;
    private ArrayList<Monitor> monitores;
    private ArrayList<Recepcionista> recepcionistas;
    private ArrayList<Limpiador> limpiadores;
    private ArrayList<Actividad> actividades;
    private String path;
    private String iconoJava;
    
    //Usuarios actuales
    private Usuario usuarioActual;
    private Socio socioActual;
    private Entrenador entrenadorActual;
    private Monitor monitorActual;
    private Recepcionista recepcionistaActual;
    private Limpiador limpiadorActual;
    private Actividad actividadActual;
    private Presidente presidenteActual;
    
    
    public Logica(ArrayList<Usuario> usuarios, String path) {
        this.usuarios = usuarios;
        this.path=path;
        this.iconoJava=path.toString()+"Gym.png";
    }
    
    

    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(ArrayList<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public ArrayList<Socio> getSocios() {
        return socios;
    }

    public void setSocios(ArrayList<Socio> socios) {
        this.socios = socios;
    }

    public ArrayList<Entrenador> getEntrenadores() {
        return entrenadores;
    }

    public void setEntrenadores(ArrayList<Entrenador> entrenadores) {
        this.entrenadores = entrenadores;
    }

    public ArrayList<Monitor> getMonitores() {
        return monitores;
    }

    public void setMonitor(ArrayList<Monitor> monitor) {
        this.monitores = monitores;
    }

    public ArrayList<Recepcionista> getRecepcionistas() {
        return recepcionistas;
    }

    public void setRecepcionista(ArrayList<Recepcionista> recepcionistas) {
        this.recepcionistas = recepcionistas;
    }

    public ArrayList<Limpiador> getLimpiadores() {
        return limpiadores;
    }

    public void setLimpiador(ArrayList<Limpiador> limpiadores) {
        this.limpiadores = limpiadores;
    }

    public ArrayList<Actividad> getActividades() {
        return actividades;
    }

    public void setActividades(ArrayList<Actividad> actividades) {
        this.actividades = actividades;
    }

    public Usuario getUsuarioActual() {
        return usuarioActual;
    }

    public void setUsuarioActual(Usuario usuarioActual) {
        this.usuarioActual = usuarioActual;
    }

    public Socio getSocioActual() {
        return socioActual;
    }

    public void setSocioActual(Socio socioActual) {
        this.socioActual = socioActual;
    }

    public Entrenador getEntrenadorActual() {
        return entrenadorActual;
    }

    public void setEntrenadorActual(Entrenador entrenadorActual) {
        this.entrenadorActual = entrenadorActual;
    }

    public Monitor getMonitorActual() {
        return monitorActual;
    }

    public void setMonitorActual(Monitor monitorActual) {
        this.monitorActual = monitorActual;
    }

    public Recepcionista getRecepcionistaActual() {
        return recepcionistaActual;
    }

    public void setRecepcionistaActual(Recepcionista recepcionistaActual) {
        this.recepcionistaActual = recepcionistaActual;
    }

    public Limpiador getLimpiadorActual() {
        return limpiadorActual;
    }

    public void setLimpiadorActual(Limpiador limpiadorActual) {
        this.limpiadorActual = limpiadorActual;
    }

    public Actividad getActividadActual() {
        return actividadActual;
    }

    public void setActividadActual(Actividad actividadActual) {
        this.actividadActual = actividadActual;
    }

    public Presidente getPresidenteActual() {
        return presidenteActual;
    }

    public void setPresidenteActual(Presidente presidenteActual) {
        this.presidenteActual = presidenteActual;
    }
    
    public String getImagen(){
        return iconoJava;
    }
    
    public String getPath(){
        return path;
    }
    
    
    
    
    
    public boolean correoUsado(String correo){//COMPRUEBA SI EL CORREO YA ESTA SIENDO USADO POR OTRO CLIENTE
        boolean usado=false;
        for(Usuario u: getUsuarios()){
               if(correo.equals(u.getEmail())){
                   usado=true;
                } 
        }
        return usado;
    }
     
    public ArrayList<String> separarPalabras(String p){//SEPARA LAS PALABRAS EN FUNCION DE LOS ESPACIOS DE UN STRING DADO
        
        ArrayList<String>  palabras=new ArrayList();
        StringTokenizer st2 = new StringTokenizer(p.concat(" "), " ");

        while (st2.hasMoreElements()) {
            palabras.add(st2.nextToken());
        } 
        return palabras;     
    }
    
    
    public ArrayList<Socio> consultarSocios(){
        
        return entrenadorActual.getSocios();
    }
    
    public ArrayList<Actividad> consultarActividades(){

        return entrenadorActual.getActividades();
    }
    
    public ArrayList<Actividad> mostrarActividades(){
       
        return actividades;
    }
    
    public void reservarActividad(){
        
        socioActual.getActividadesReservadas().add(actividadActual);
    }
    
    public void puntuarMonitor(Integer puntuacion){
        
        monitorActual.getPuntuaciones().add(puntuacion);
    }
    
    public double mediaPuntuaciones(){
        
        Integer suma=0;
        
        for(int x = 0; x < monitorActual.getPuntuaciones().size(); x++){
            suma += monitorActual.getPuntuaciones().get(x);
        }
        double media = suma / monitorActual.getPuntuaciones().size();
        
        return media = monitorActual.getPuntuacion();
    }
    
    public double mediaPuntuacionesMonitor(Monitor nombre){
        
        Integer suma=0;
        
        for(int x = 0; x < nombre.getPuntuaciones().size(); x++){
            suma += nombre.getPuntuaciones().get(x);
        }
        double media = suma / nombre.getPuntuaciones().size();
        
        return media = nombre.getPuntuacion();
    }
    
    public String consultarPuntuaciones(){
        
        //ArrayList<Monitor> monitores = new ArrayList<Monitor>();
        String consulta = "";
       
        for(Monitor m: getMonitores()){
            consulta = consulta + m.getNombre()+String.valueOf(m.getPuntuacion());
        }
        return consulta;     
    }
    
    public void añadirActividad(Actividad nuevaActividad){

        actividades.add(nuevaActividad);
    }
    
    public void eliminarActividad(Actividad act){
        actividades.remove(act);
    }
    
    
    public String verZonaLimpieza(){
        
        String zona = limpiadorActual.getZona();
        
        return zona;
    }
    
    public String verZonaTurnoLimpieza(){

        String turno = limpiadorActual.getTurno();
        
        return turno;
    }
    
    public void cambiarTurno(String nuevoTurno){

        limpiadorActual.setTurno(nuevoTurno);
    }
    
    public void modificarZona(String nuevaZona){
        
        limpiadorActual.setZona(nuevaZona);
    }
    
    public void darAlta(Socio nuevoSocio){
        socios.add(nuevoSocio);
    }
    
    public void darBaja(Socio soc){
        socios.remove(soc);
    }
    
    
}
