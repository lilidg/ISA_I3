
package Clases;

import java.util.ArrayList;

public class Monitor extends Usuario {
    
    private String turno;
    private double puntuacion;
    private ArrayList<Integer> puntuaciones;

    public Monitor(String turno, int id, String dni, String nombre, String email, String clave) {
        super(id, dni, nombre, email, clave);
        this.turno = turno;
    }
    

 
    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public double getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(double puntuacion) {
        this.puntuacion = puntuacion;
    }

    public ArrayList<Integer> getPuntuaciones() {
        return puntuaciones;
    }

    public void setPuntuaciones(ArrayList<Integer> puntuaciones) {
        this.puntuaciones = puntuaciones;
    }
    
    
}
