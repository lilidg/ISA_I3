
package Clases;

public class Presidente extends Usuario{

    public Presidente(int id, String dni, String nombre, String email, String clave) {
        super(id, dni, nombre, email, clave);
    }
    
    
       
}
