
package Clases;

public class Recepcionista extends Usuario{

    public Recepcionista(int id, String dni, String nombre, String email, String clave) {
        super(id, dni, nombre, email, clave);
    }

    
    
}
