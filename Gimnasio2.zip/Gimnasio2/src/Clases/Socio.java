
package Clases;

import java.io.Serializable;
import java.util.ArrayList;


public class Socio extends Usuario implements Serializable{
    
    private String telefono;
    private double cuota;
    private String cuenta;
    private ArrayList<Actividad> actividadesReservadas;
    private boolean inicializado=false;

    public Socio(String telefono, double cuota, String cuenta, int id, String dni, String nombre, String email, String clave) {
        super(id, dni, nombre, email, clave);
        this.telefono = telefono;
        this.cuota = cuota;
        this.cuenta = cuenta;
        this.inicializado=true;
    }


    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public double getCuota() {
        return cuota;
    }

    public void setCuota(double cuota) {
        this.cuota = cuota;
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public ArrayList<Actividad> getActividadesReservadas() {
        return actividadesReservadas;
    }

    public void setActividadesReservadas(Actividad e) {
        actividadesReservadas.add(e);
    }
    
    public boolean getInicializado() {
        return inicializado;
    }
    
    
}
